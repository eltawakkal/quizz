<?php

namespace App\Models\Data;

use Illuminate\Database\Eloquent\Model;

class Mitra extends Model
{
    protected $fillable = [
        'name',
        'logo'
    ];
}

<?php

namespace App\Models\Item;

use Illuminate\Database\Eloquent\Model;

class QuizItemType extends Model
{
    //
}

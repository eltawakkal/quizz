<?php

namespace App\Models\LandingPage;

use Illuminate\Database\Eloquent\Model;

class Setting extends Model
{
    //
}

<?php

namespace App\Livewire\LandingPage;

use Livewire\Component;

class Penelitian extends Component
{
    public function render()
    {
        return view('livewire.landing-page.penelitian');
    }
}
